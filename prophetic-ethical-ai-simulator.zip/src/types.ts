/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CorePrinciple {
  name: string;
  status: string;
  notes: string;
}

export interface Layer0Philosophy {
  alignment: string;
  principlesChecked: CorePrinciple[];
}

export interface Layer1Identity {
  intentClassified: string;
  intentionAnalysis: string;
  moralRiskScore: number;
  trustAdjustment: number;
}

export interface GovernanceAgent {
  name: string;
  comment: string;
}

export interface Layer2Governance {
  agents: GovernanceAgent[];
  voteOutcome: string;
  shuraDecisionSummary: string;
}

export interface Layer3SocialUmmah {
  nodesAffected: string[];
  trustGraphUpdate: string;
  resourceRedistributionTrigger: string;
  resourceDetails: string;
}

export interface Layer4Economy {
  antiExploitCheck: string;
  subsidyRequired: boolean;
  subsidyDetails: string;
  fairTransactionComment: string;
}

export interface Layer5Conflict {
  conflictLevel: string;
  mediationSteps: string[];
  reconciliationStrategy: string;
}

export interface Layer6Knowledge {
  historicalReference: string;
  seerahDetails: string;
  evidenceQuote: string;
  noHallucinationFlag: boolean;
}

export interface ApiAction {
  trigger: string;
  params: Record<string, any>;
}

export interface Layer7Action {
  apiActions: ApiAction[];
}

export interface Layer8SafetyMercy {
  globalHarmScore: number;
  killSwitchStatus: string;
  mercyOverrideActive: boolean;
  mercyRecommendation: string;
}

export interface PiaisSimulationResponse {
  originalScenario: string;
  language: string;
  layer0: Layer0Philosophy;
  layer1: Layer1Identity;
  layer2: Layer2Governance;
  layer3: Layer3SocialUmmah;
  layer4: Layer4Economy;
  layer5: Layer5Conflict;
  layer6: Layer6Knowledge;
  layer7: Layer7Action;
  layer8: Layer8SafetyMercy;
  simulatedBy?: string;
}

// Sandbox state types
export interface SandboxState {
  initialTrust: number;
  communityNeediness: number;
  conflictSeverity: number;
  monopolyLevel: number;
  mercyFactor: number;
}
