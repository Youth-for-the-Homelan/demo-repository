/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ARCHITECTURE_LAYERS, LayerMetadata } from "../data";
import { Shield, Sparkles, Network, Scale, Users, Heart, BookOpen, Settings, Zap, Compass } from "lucide-react";

interface ArchitectureViewerProps {
  isArabic: boolean;
}

const LAYER_ICONS: Record<string, React.ComponentType<any>> = {
  "core-ethics": Compass,
  "intent-engine": Shield,
  "shura-governance": Users,
  "ummah-social-graph": Network,
  "fair-economy": Scale,
  "peace-mediation": Heart,
  "revelation-knowledge": BookOpen,
  "action-execution": Settings,
  "safety-mercy": Zap,
};

export default function ArchitectureViewer({ isArabic }: ArchitectureViewerProps) {
  const [selectedLayerId, setSelectedLayerId] = useState<number | null>(0);

  const getIcon = (slug: string) => {
    return LAYER_ICONS[slug] || Sparkles;
  };

  return (
    <div id="architecture-viewer-section" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Sidebar List of 9 Layers */}
      <div className="lg:col-span-4 space-y-3">
        <h3 className="text-sm font-semibold text-[#c5a059] tracking-wider uppercase mb-2 flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-[#c5a059] rounded-full" />
          {isArabic ? "طبقات وهيكل النظام الـ 9" : "System Architecture Layers (9)"}
        </h3>
        <p className="text-xs text-[#888891] mb-4">
          {isArabic 
            ? "انقر على أي طبقة لاستكشاف الترجمة الهندسية والسند التاريخي من سيرة نبي الرحمة." 
            : "Select any layer to explore its system specification and historical context from the Prophetic biography."}
        </p>

        <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
          {ARCHITECTURE_LAYERS.map((layer) => {
            const Icon = getIcon(layer.slug);
            const isSelected = selectedLayerId === layer.id;

            return (
              <button
                key={layer.id}
                id={`layer-btn-${layer.id}`}
                onClick={() => setSelectedLayerId(layer.id)}
                className={`w-full text-left p-3.5 rounded border transition-all duration-300 relative overflow-hidden flex items-center gap-3.5 focus:outline-none ${
                  isSelected
                    ? "bg-[#1d1d24] border-[#c5a059] text-[#e0e0e6] shadow-sm shadow-[#c5a059]/10"
                    : "bg-[#141418] border-[#2d2d35] hover:bg-[#1d1d24]/50 text-[#888891] hover:text-[#e0e0e6]"
                }`}
              >
                {isSelected && (
                  <motion.div
                    layoutId="active-layer-indicator"
                    className="absolute inset-y-0 left-0 w-1 bg-[#c5a059]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                
                <div className={`p-2 rounded ${isSelected ? "bg-[#c5a059] text-[#08080a]" : "bg-[#2d2d35] text-[#888891]"}`}>
                  <Icon className="h-4 w-4" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] tracking-wider text-[#888891] font-mono">L{layer.id}</span>
                  </div>
                  <h4 className="font-semibold text-xs sm:text-sm truncate">
                    {isArabic ? layer.nameAr : layer.nameEn}
                  </h4>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Layer Content Viewer */}
      <div className="lg:col-span-8">
        <AnimatePresence mode="wait">
          {selectedLayerId !== null && (() => {
            const layer = ARCHITECTURE_LAYERS.find((l) => l.id === selectedLayerId);
            if (!layer) return null;
            const Icon = getIcon(layer.slug);

            return (
              <motion.div
                key={layer.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="bg-[#141418] border border-[#2d2d35] rounded p-5 sm:p-7 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
              >
                {/* Visual decoration overlay */}
                <div className="absolute top-0 right-0 w-44 h-44 bg-[#c5a059]/5 rounded-full blur-3xl -mr-12 -mt-12 pointer-events-none" />

                <div>
                  {/* Layer Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#2d2d35]">
                    <div className="flex items-center gap-3.5">
                      <div className="p-3 rounded bg-[#1d1d24] text-[#c5a059] border border-[#2d2d35]">
                        <Icon className="h-6 w-6" />
                      </div>
                      <div>
                        <span className="text-[10px] font-mono font-bold text-[#c5a059]">LAYER {layer.id} SYSTEM NODE</span>
                        <h2 className="text-base sm:text-lg font-bold text-[#e0e0e6] tracking-tight">
                          {isArabic ? layer.nameAr : layer.nameEn}
                        </h2>
                      </div>
                    </div>
                  </div>

                  {/* Operational Philosophy */}
                  <div className="mt-6 space-y-6">
                    <div>
                      <h5 className="text-[10px] font-mono text-[#888891] uppercase tracking-widest mb-2 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 bg-[#c5a059] rounded-full" />
                        {isArabic ? "الفلسفة التشغيلية للطبقة" : "Operational Cybernetic Philosophy"}
                      </h5>
                      <p className="text-[#e0e0e6] leading-relaxed text-xs sm:text-sm">
                        {isArabic ? layer.philosophyAr : layer.philosophyEn}
                      </p>
                    </div>

                    {/* Algorithmic & Software Integration */}
                    <div className="bg-[#0c0c0e] hover:bg-[#141418] transition-colors p-4 rounded border border-[#2d2d35] space-y-2">
                      <h5 className="text-[10px] font-mono text-[#00d4ff] uppercase tracking-widest flex items-center gap-2">
                        <Settings className="h-3.5 w-3.5 text-[#00d4ff]" />
                        {isArabic ? "الصياغة والترجمة البرمجية (Engineering Code Specs)" : "Algorithmic Specification & Rules"}
                      </h5>
                      <p className="text-xs text-[#888891] leading-relaxed font-mono">
                        {isArabic ? layer.technicalTranslationAr : layer.technicalTranslationEn}
                      </p>
                    </div>

                    {/* Historical Seerah Validation */}
                    <div className="space-y-4">
                      <div className="space-y-2.5">
                        <h5 className="text-[10px] font-mono text-[#c5a059] uppercase tracking-widest flex items-center gap-1.5">
                          <BookOpen className="h-3.5 w-3.5 text-[#c5a059]" />
                          {isArabic ? "السند والتطبيق الميداني من السيرة النبوية" : "Precedent from Prophetic Biography (Seerah)"}
                        </h5>
                        <div className="border-l border-[#c5a059]/30 pl-4 py-1 italic text-[#e0e0e6]/90 text-xs leading-relaxed">
                          {isArabic ? layer.seerahPrecedentAr : layer.seerahPrecedentEn}
                        </div>
                      </div>

                      {layer.caliphatePrecedentAr && (
                        <div className="space-y-2.5 pt-3 border-t border-[#2d2d35]/50">
                          <h5 className="text-[10px] font-mono text-[#bf9546] uppercase tracking-widest flex items-center gap-1.5">
                            <Users className="h-3.5 w-3.5 text-[#bf9546]" />
                            {isArabic ? "الامتداد في عهد الخلفاء الراشدين رضي الله عنهم" : "Extension in the Righteous Caliphs Era"}
                          </h5>
                          <div className="border-l border-[#bf9546]/30 pl-4 py-1 italic text-[#e0e0e6]/90 text-xs leading-relaxed">
                            {isArabic ? layer.caliphatePrecedentAr : layer.caliphatePrecedentEn}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Hadith / Axiom Box */}
                <div className="mt-8 pt-5 border-t border-[#2d2d35] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="bg-[#1d1d24] p-3 rounded. border border-[#c5a059]/20 w-full flex items-center gap-3">
                    <span className="text-lg">📜</span>
                    <div>
                      <span className="text-[9px] font-mono uppercase tracking-wider text-[#c5a059] block">
                        {isArabic ? "الحديث الشريف المستند" : "Validating Prophetic Axiom / Hadith"}
                      </span>
                      <p className="text-xs font-semibold text-[#e0e0e6] italic mt-0.5">
                        {isArabic ? layer.hadithAr : layer.hadithEn}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })()}
        </AnimatePresence>
      </div>
    </div>
  );
}

