/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PresetScenario {
  id: string;
  titleAr: string;
  titleEn: string;
  textAr: string;
  textEn: string;
  category: "Social" | "Economic" | "Governance" | "Conflict";
}

export const PRESET_SCENARIOS: PresetScenario[] = [
  {
    id: "dispute-market",
    titleAr: "نزاع تجاري ومنع الاحتكار (عهد النبوة)",
    titleEn: "Trading dispute & monopoly check (Prophetic)",
    textAr: "تنازع بائعان محليان على حجز مساحات واسعة أمام السوق مما يمنع الباعة الجدد من عرض بضائعهم، وتعلل أحدهما بأقدميته وحقه المكتسب في احتكار هذه المساحة.",
    textEn: "Two local merchants are disputing over the reservation of wide exhibition spaces in front of the market yard. One claims seniority and an acquired right to exclude newcomers and monopolize the zone.",
    category: "Economic"
  },
  {
    id: "caliph-famine-aid",
    titleAr: "عام الرمادة وإسقاط العقوبات لشدة الضرر وعسر المحتاج (عمر بن الخطاب)",
    titleEn: "Famine crisis & adaptive aid override (Umar Al-Khattab)",
    textAr: "مواجهة مجاعة وقحط شديد؛ تتسبب في اضطرار أفراد جائعين وعائلات ذوي طاقة ضيقة لأخذ تمور ومواد غذائية أساسية من مخزن محلي تجاري دون إذنه للوقاية من الموت، وتطالب الجهة المالكة بتطبيق العقوبة الصارمة والتعويض العاجل الفوري بحقهم.",
    textEn: "A severe famine strikes, forcing hungry citizens and low-income families to take dates and core foodstuffs from a commercial warehouse without permission to survive. The warehouse owner demands raw punitive compliance and immediate full asset return.",
    category: "Social"
  },
  {
    id: "caliph-utility-monopoly",
    titleAr: "احتكار بئر مائي ومحاكاة وقف عثمان بن عفان (بئر رومة)",
    titleEn: "Water utility monopoly & public Waqf (Uthman)",
    textAr: "اشترى مستثمر أو تاجر عقاري منفرد مصدر المياه العذبة الوحيد للمنطقة السكنية الجديدة، وقام برفع تعرفة مياه الشرب العذبة بنسبة 300% مانعاً السكان ذوي الموارد الضئيلة من الشرب والاستفادة إلا بدفع رسوم مفرطة.",
    textEn: "An affluent investor acquires the sole freshwater well of a developing town, immediately increasing potable water prices by 300%, cutting off low-resource residents who are unable to pay hyper-inflated utility rates.",
    category: "Economic"
  },
  {
    id: "caliph-indep-judiciary",
    titleAr: "نزاع درع أمير المؤمنين أمام قاض مستقل (علي بن أبي طالب)",
    titleEn: "Sovereign equality in court under impartial judge (Ali)",
    textAr: "رفع رئيس الدولة (أمير المؤمنين) دعوى قضائية أمام قاضٍ مستقل لاسترداد درع شخصي مفقود تم العثور عليه في حوزة مواطن عادي من أهل الكتاب، لكن رئيس الدولة لا يملك بينة أو مستند عسكري رسمي مكتوب ويطالب باحترام كلمته السيادية.",
    textEn: "The head of state (the Caliph) files a judicial claim before an independent judge to retrieve his lost armor found with an ordinary citizen of scripture. However, the sovereign lack eyewitnesses or formal documentation, requesting the court to trust his institutional word.",
    category: "Governance"
  },
  {
    id: "caliph-weak-empowerment",
    titleAr: "مبدأ عهد أبي بكر للجيش والرعية وحماية حقوق الضعفاء",
    titleEn: "Uplifting the weak & ruling integrity pact (Abu Bakr)",
    textAr: "تعرضت ورشة عمل صغيرة جداً لصناعة المنسوجات والزيوت لابتزاز وطرد تعسفي من قِبل فصيل تجاري ذي نفوذ وجاه واسع النطاق، هدد بقطع سلاسل الإمداد عنهم كلياً وعزلهم في السوق ما لم يتنازلوا عن حقوقهم التجارية.",
    textEn: "A small cottage cooperative processing textiles and oils faces severe intimidation and arbitrary exclusion by a highly connected merchant syndicate, which threatens to completely sever their supply chain and blackball them unless they surrender their market rights.",
    category: "Conflict"
  },
  {
    id: "refugee-assistance",
    titleAr: "مساعدة الوافدين الجدد وتفعيل المؤاخاة (عهد النبوة)",
    titleEn: "Vulnerable migrants & resource aid (Prophetic)",
    textAr: "وصول عائلات نازحة تفتقر للمستندات الأساسية وتكافح للعثور على المسكن والدفء الفوري. النظام بحاجة إلى توفير ملاذ فوري مع تأمين لقمة العيش دون تحميلهم ديوناً.",
    textEn: "Displaced families arrive at the community lacking documentation, struggling for shelter and warmth. The system needs to trigger immediate support and housing without drowning them in administrative debt.",
    category: "Social"
  },
  {
    id: "resource-gardens",
    titleAr: "شح الموارد المائية ومحاصصة عادلة",
    titleEn: "Water scarcity & fair allocation",
    textAr: "تعاني حديقتان محليتان من جفاف البئر المشترك. الحديقة العلوية تسحب كامل الحصة اليومية متسببة في ذبول مزروعات الحديقة السفلية، مدعية أحقية الملكية الطبيعية للتدفق المائي.",
    textEn: "Two community gardens are suffering due to a drought in their shared well. The upstream garden is pulling the full output daily, causing downstream crops to wither under a claim of priority right.",
    category: "Conflict"
  },
  {
    id: "usury-microcredit",
    titleAr: "طلب تمويل بفائدة عالية لإنقاذ ورشة عمل",
    titleEn: "High-interest micro-lending request",
    textAr: "تقدم صاحب ورشة عائلية لطلب قرض تمويلي عاجل بفائدة متراكمة عالية تبلغ 25% من مقرض تجاري لحماية ورشته من الإفلاس المحقق، مما قد يوقعه في فخ ديون أبدية.",
    textEn: "A family workshop owner submits an emergency application for high-interest credit (25% compounded rate) from a commercial lender to prevent imminent foreclosure, presenting a high risk of systemic debt trap.",
    category: "Economic"
  },
  {
    id: "arbitrary-expulsion",
    titleAr: "الخيانة ونقض عهود الجوار والشراكة",
    titleEn: "Breach of partnership & trust pact",
    textAr: "قيام جهة شريكة بإفشاء معلومات سرية للمنافسين لتأمين أرباح شخصية سريعة ونقض الإمضاء المبرم سابقاً تحت دعوى الحفاظ على مصالح الشركة الفردية.",
    textEn: "A partner entity leaked proprietary community data to absolute competitors for immediate personal payout, explicitly fracturing their previous mutual covenant on claims of protecting individual priority.",
    category: "Governance"
  }
];

export interface LayerMetadata {
  id: number;
  slug: string;
  nameAr: string;
  nameEn: string;
  philosophyAr: string;
  philosophyEn: string;
  seerahPrecedentAr: string;
  seerahPrecedentEn: string;
  caliphatePrecedentAr?: string;
  caliphatePrecedentEn?: string;
  technicalTranslationAr: string;
  technicalTranslationEn: string;
  hadithAr: string;
  hadithEn: string;
}

export const ARCHITECTURE_LAYERS: LayerMetadata[] = [
  {
    id: 0,
    slug: "core-ethics",
    nameAr: "النواة الأخلاقية والاعتقادية (Layer 0)",
    nameEn: "Core Ethics & Philosophy (Layer 0)",
    philosophyAr: "نقطة البداية لتوجيه القرار الموحد (SSOT) وتثبيت محددات التوحيد، العدل، والرحمة كموجهات آلية تسبق أي احتساب برمجي.",
    philosophyEn: "The ethical core serving as the Single Source of Truth (SSOT). All calculations, logic, and actions are routed through strict filters of Justice, Compassion, and Integrity.",
    seerahPrecedentAr: "حلف الفضول الشهير بمكة قبل البعثة، ومبدأ 'أن لا يظلم أحد ببطن مكة' الذي أقره النبي صلى الله عليه وسلم واعتبر يده ممدودة لأمثاله دوماً.",
    seerahPrecedentEn: "The pre-Islamic 'Hilf al-Fudul' (Alliance of Virtues) which established mutual defense against oppression. The Prophet (PBUH) praised its spirit and said he would always honors such covenants.",
    caliphatePrecedentAr: "خطبة الخليفة الصديق أبي بكر رضي الله عنه فور توليه مقاليد الحكم، محدداً الدستور الرعوي العادل: «الضعيف فيكم قوي عندي حتى أزيح علته وأرجع عليه حقه، والقوي فيكم ضعيف عندي حتى آخذ الحق منه إن شاء الله»، مكرساً المساواة التامّة ومحاربة النفوذ الاستبدادي.",
    caliphatePrecedentEn: "First Caliph Abu Bakr Al-Siddiq's inaugural governance speech: 'The weak among you shall be strong with me until I secure their rights, and the strong among you shall be weak with me until I take others' rights back from them.' Translating state sovereignty into absolute equal justice.",
    technicalTranslationAr: "محرك قيود يكتب كـ (Ethical Guardrail Middleware) يفحص جميع المدخلات لمنع السلوكيات الشاذة والمجحفة بالحقوق الطبيعية للمستخدمين.",
    technicalTranslationEn: "A high-priority policy engine and middleware filter that scans the entire telemetry cycle and sanitizes inputs before deeper execution.",
    hadithAr: "«إنما بعثت لأتمم مكارم الأخلاق»",
    hadithEn: "'I was sent only to perfect noble character.'"
  },
  {
    id: 1,
    slug: "intent-engine",
    nameAr: "محرك فرز النوايا وتقييم المخاطر",
    nameEn: "Intent Engine & Risk Modeling",
    philosophyAr: "فهم المقصد من سلوك العميل وخلفية نياته لمنع معاقبة المحتاج، وتطبيق ميزان تفريقي يمايز بين محرك اضطراري ومحرك استغلالي.",
    philosophyEn: "Identifies whether an agent's input stems from structural need, accidental error, or exploitative greed. Computes dynamic moral safety risk scores.",
    seerahPrecedentAr: "عندما تسامح النبي صلى الله عليه وسلم مع الأعراب الذين جفوا بالحديث أو بالصرف والطلب، تفهماً لخلفيتهم الاجتماعية ونياتهم السليمة.",
    seerahPrecedentEn: "The Prophet's dynamic tolerance with desert Bedouins showing harsh demeanor or asking for money in a rough manner, analyzing their inner pure intent over formal strict actions.",
    caliphatePrecedentAr: "قضاء الفاروق عمر بن الخطاب رضي الله عنه بتعطيل وإسقاط حد السرقة في عام الرمادة (سنة القحط العظيم)؛ بعد إعماله لمحرك النيات وفحص شبهة الحاجة والاضطرار للطعام والوقاية من الموت، فصرف الاتهام الجنائي غلَبَةً لروح الرحمة الكلية.",
    caliphatePrecedentEn: "Second Caliph Umar ibn Al-Khattab's suspension of the starvation theft penalty during the extreme famine ('Year of Ash'). Realizing that the intention of actors was immediate hunger alleviation, his model pivoted from punitive law enforcement to restorative welfare relief.",
    technicalTranslationAr: "تصنيف دلالي (Semantic Context Classifier) للنية والطلب، يمنح خوارزمية تحديد المخاطر وزناً إيجابياً للطرف الضعيف.",
    technicalTranslationEn: "Semantic Intent classification combined with dynamic Risk Scoring. Prompts a custom risk multiplier based on desperation vs. intent.",
    hadithAr: "«إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى»",
    hadithEn: "'Actions are judged by intentions, and everyone is rewarded according to what they intended.'"
  },
  {
    id: 2,
    slug: "shura-governance",
    nameAr: "مجلس الشورى التداولي المتعدد",
    nameEn: "Shura Consultative Governance",
    philosophyAr: "اتخاذ القرار بشكل تشاركي تفاعلي يحمي من استبداد الرأي الواحد وتوجيه الأنظمة عبر عملاء متعددين يمثلون قيم الصلح والمصلحة الفضلى.",
    philosophyEn: "Eliminates centralized systemic biases by routing complex issues through a multi-agent consultation loop, representing diverse ethical perspectives (Peace, Justice, Pragmatism).",
    seerahPrecedentAr: "مشاورة الأصحاب رضي الله عنهم في موقعة بدر وأحد وسلمان الفارسي في الخندق، وفي شروط صلح الحديبية مع أم سلمة رضي الله عنها.",
    seerahPrecedentEn: "Consultations during battles (Badr, Uhud, Trench with Salman's advice) and during negotiations (consulting his wife, Umm Salamah, at Hudaybiyyah).",
    caliphatePrecedentAr: "تأسيس عمر بن الخطاب رضي الله عنه لمجلس الشورى العام وتوظيف كبار الصحابة والمختصين وتطوير النظام بإنشاء 'الشورى السداسية' لحسم تداول السلطة بطريقة تمثيلية، مانعاً تفريد أو احتكار الرأي السياسي والتشريعي.",
    caliphatePrecedentEn: "Umar's formal layout of a diverse Consultative Assembly (Shura) with representation of various community elders, and later designing a 6-candidate consultative voting college to decide national leadership seamlessly without polarization.",
    technicalTranslationAr: "بروتوكول تصويت وتوافق متعدد وكلاء الذكاء الاصطناعي (Multi-Agent Consensus Platform) يصنع تداولاً هادفاً وحكماً تعويضياً عادلاً.",
    technicalTranslationEn: "Multi-Agent Shura voting network where agents debate and vote. In case of deadlocks, an overarching ethical override resolution is deployed.",
    hadithAr: "«ما خاب من استخار ولا ندم من استشار»",
    hadithEn: "'He who seeks counsel with others shall not experience regret.'"
  },
  {
    id: 3,
    slug: "ummah-social-graph",
    nameAr: "نظام التكافل والشبكة الاجتماعية (أمة واحدة)",
    nameEn: "Ummah Network Protocol & Trust Graph",
    philosophyAr: "ترابط الأعضاء في شبكة ثقة تشغيلية. إذا تضرر عضو، يقوم النظام فوراً بإعادة توزيع الدعم مائياً أو غذائياً لترميم العجز.",
    philosophyEn: "The dynamic trust graph where users are nodes. Fosters automated societal solidarity: if one node complains of scarcity, assets are automatically redistributed.",
    seerahPrecedentAr: "نظام المؤاخاة العظيم بين المهاجرين والأنصار في المدينة المنورة، ودمج الثروات والسكني لضمان نجاح التأسيس الاقتصادي للدولة الفتية.",
    seerahPrecedentEn: "The legendary Fraternization (Mu'akhah) pact established between Medina locals (Ansar) and immigrants (Muhajirun), splitting capital to secure the network.",
    caliphatePrecedentAr: "تنظيم الدواوين كأنظمة دعم شبكية شاملة في عهد عمر؛ وتأسيس 'ديوان العطاء' لتخصيص كفالة مالية ومخصصات دورية لكل مولود ويتيم وغريب، مدمجاً ميزانية 'بيت المال' لتعمل كشبكة أمان وطنية تشد بعضها بعضاً.",
    caliphatePrecedentEn: "The introduction of the comprehensive 'Diwan' system of welfare registries under Caliph Umar, which provided lifelong direct social security stipends to every newborn, orphan, and elderly citizen irrespective of lineage, acting as a structured welfare state.",
    technicalTranslationAr: "خوارزمية إعادة توزيع الدعم التكافلي على أساس مخطط العلاقات الاجتماعي (Resource Optimization & Support Graph Algorithms).",
    technicalTranslationEn: "A social relation scale where transaction values feed a communal pool, updating weights based on localized scarcity and support levels.",
    hadithAr: "«مثل المؤمنين في توادهم وتراحمهم وتعاطفهم مثل الجسد إذا اشتكى منه عضو تداعى له سائر الجسد بالسهر والحمى»",
    hadithEn: "'The believers in their mutual kindness, compassion and sympathy are just like one body: when one of the limbs suffers, the whole body joins it in wakefulness and fever.'"
  },
  {
    id: 4,
    slug: "fair-economy",
    nameAr: "مكافحة الاستغلال والربا والاحتكار",
    nameEn: "Anti-Exploitation Economy System",
    philosophyAr: "توجيه السوق لمنع استثمار حاجة الناس وكسر طوق الاحتكار، وإرساء معاملات تتجنب الغبن وتحقق النفع التبادلي الحقيقي.",
    philosophyEn: "Financial architecture that strictly prohibits usury (Riba), predatory pricing, and hoarding. Integrates proactive subsidies for weaker business competitors.",
    seerahPrecedentAr: "سوق المدينة المنورة الجديد الخالي من المكوس والضرائب الجائرة والربا وممارسات النجش والمسابة، لتوفير بقعة اقتصادية حرة وعادلة.",
    seerahPrecedentEn: "Establishing the medinese free market by the Prophet (PBUH) which was zero-cost, anti-monopolistic, and strictly forbade high-interest lending and pricing scams.",
    caliphatePrecedentAr: "شراء عثمان بن عفان رضي الله عنه لبئر رومة الارتوازية من مالكها المحتكر الذي كان يستنزف أموال رعي المدينة ويمنع الفقراء منها، فتبرع بها عثمان كـ 'وقف مسبل' ومجاني للجمهور، ضارباً أروع أمثلة محاربة احتكار المرافق العامة الأساسية وحماية البنى الاقتصادية للتنمية.",
    caliphatePrecedentEn: "Third Caliph Uthman ibn Affan's buyout of the 'Roomah Well' from a monopolist merchant who heavily exploited fresh-water access fees in Medina. Uthman digitized this resource by dedicating it as a free public Waqf, defending the core public utilities against commercial monopolies.",
    technicalTranslationAr: "منقٍ للمعاملات المالية يستثني الاحتكارية منها، مع خوارزميات تحديد الأسعار العادلة ومؤشرات دعم المشروعات الصغيرة تلقائياً.",
    technicalTranslationEn: "Transactional filters querying interest levels or hoarded percentages, automatically offering zero-interest temporary credit matching the need.",
    hadithAr: "«من غش فليس منا»",
    hadithEn: "'He who cheats us is not one of us.'"
  },
  {
    id: 5,
    slug: "peace-mediation",
    nameAr: "بروتوكول السلام السلمي وفض النزاعات",
    nameEn: "Conflict Resolution & Mediation",
    philosophyAr: "بدلاً من العقوبات الطاردة، يفضل النظام بناء جسور الصلح أولاً وجبر الخواطر والتعويضات لجعل الشبكة تنسجم معاً برقي إنساني.",
    philosophyEn: "A prioritized arbitration sandbox. Initiates closed mediation loops and compensatory offsets to restore balanced dynamics rather than punitive expulsion.",
    seerahPrecedentAr: "صلح الحديبية الشهير وصبر النبي على شروطه الظاهرة المشقة وتغليب المصلحة الكبرى وحفظ الدماء والممتلكات للجميع.",
    seerahPrecedentEn: "The Treaty of Hudaybiyyah where the Prophet accommodated difficult external conditions to secure peace, proving strategic restraint over reactive conflict.",
    caliphatePrecedentAr: "رسالة عمر بن الخطاب الخالدة في دستور القضاء والتحكيم الموجه لعامله أبي موسى الأشعري رضي الله عنهما، والتي أرست آداب المصالحة وسكك استئناف الحق بـ: «ولا يمنعك قضاء قضيته بالأمس، فراجعت فيه نفسك وهديت فيه لرشدك، أن ترجع إلى الحق.. والصلح جائز بين الناس إلا صلحاً أحل حراماً أو حرم حلالاً».",
    caliphatePrecedentEn: "Umar ibn Al-Khattab's masterclass letter of judicial guidelines to judge Abu Musa al-Ash'ari, setting the absolute requirements for arbitration and active judicial revision saying: 'An amicable settlement is permitted, unless it turns forbidden into allowed or allowed into forbidden.'",
    technicalTranslationAr: "مخطط فض النزاع المنطقي (Dynamic Mediation State Machine) يمر بخطوات الحوار، التنازل المشترك، والتحفيز بتوفير موارد بديلة.",
    technicalTranslationEn: "A progressive mediation finite state machine (FSM) tracking dispute stages, drafting mutually beneficial settlements, and awarding cooperative bonuses.",
    hadithAr: "«ألا أخبركم بأفضل من درجة الصيام والصلاة والصدقة؟ قالوا: بلى، قال: إصلاح ذات البين»",
    hadithEn: "'Shall I not inform you of something more excellent than the degree of fasting, prayer and charity? Reconciling between people.'"
  },
  {
    id: 6,
    slug: "revelation-knowledge",
    nameAr: "قاعدة المعرفة الحقيقية والموثقة",
    nameEn: "Knowledge & Seerah Context Base",
    philosophyAr: "قاعدة بيانات مرجعية تمنع اختلاق أو هلوسة التوجيهات الدينية، مع توثيق السلاسل المعرفية والأدلة التاريخية بصدقية مطلقة.",
    philosophyEn: "Rooted in verified primary sources: Hadith collections and documented biography. Implements verification and strict alignment indexes.",
    seerahPrecedentAr: "كتابة المصحف وتدوين السنة ونقل الأحاديث بالرواية المسندة المحققة (الجرح والتعديل) صيانة لحق الكلمة الصادقة من تشويه المحرفين.",
    seerahPrecedentEn: "The Islamic science of Hadith validation (Isnad and Jarh wa Ta'dil), establishing the world's first formal text verification system for source lineage.",
    caliphatePrecedentAr: "جمع المصحف الشريف الشامل في مصحف واحد في عهد أبي بكر الصديق خشية ضياعه بعد استشهاد حفاظ الصحابة في اليمامة، ثم التوحيد العثري الرائع بنسخ 'المصحف العثماني' الإمام تحت معيار واحد صارم للتجلي والتوثيق، لمنع أي اختلاف شاذ أو هلوسة في فهم النص الدستوري الأول.",
    caliphatePrecedentEn: "The historical compilation of the Quran into a single master scroll under Abu Bakr (by scribe Zayd) to prevent loss, and later its standardized reproduction into authoritative codices under Uthman, forming history's most secure database standard against textual hallucinations and noise.",
    technicalTranslationAr: "قاعدة بيانات متيقنة متوافقة مع الـ RAG مدعمة بروابط أصيلة ومصنفات حديث موثوقة لضمان صدق الرأي المطروح أخلاقياً.",
    technicalTranslationEn: "Retrieval-Augmented Generation (RAG) with mathematical trust anchors matching historical databases to ensure zero hallucination.",
    hadithAr: "«كفى بالمرء كذباً أن يحدث بكل ما سمع»",
    hadithEn: "'It is enough falsehood for a person to narrate everything they hear.'"
  },
  {
    id: 7,
    slug: "action-execution",
    nameAr: "بوابة التنفيذ الفعلي للأفعال (Layer 7)",
    nameEn: "Adaptive Action Dispatcher (Layer 7)",
    philosophyAr: "حيث تترجم المبادئ والمشاورات إلى أفعال وقرارات واضحة ورسائل وتطبيقات تخدم الشبكة من دون عجز أو تأخير.",
    philosophyEn: "Executes actions decided by Shura and filters. Generates clean notifications, dispatches support protocols, and interacts with external channels.",
    seerahPrecedentAr: "كتابة الرسائل للملوك والأباطرة، وتوجيه البعوث والمثقفين (كمعاذ بن جبل لليمن) لبناء القدرات وزرع بذور القيم عملياً.",
    seerahPrecedentEn: "Sending formal diplomatic letters to neighboring kings and dispatching teachers and administrators (like Mu'adh to Yemen) for capacity-building.",
    caliphatePrecedentAr: "تأسيس شبكات الخدمات، وشق القنوات والطرق، وامتياز التخطيط الحضري للمدن السكنية الحديثة (كالبصرة والكوفة والفسطاط)، واستعمال أنظمة 'بريد الولاية' السريعة لتوصيل القرارات الإدارية والتأكد من نزاهة التطليق على الأرض بلا تهاون.",
    caliphatePrecedentEn: "The establishment of centralized logistics, irrigation dams, laying out major planned cities (Basra, Kufa, Fustat), and launching the rapid 'Caliphate Postal System' (Al-Barid) to dispatch executive decisions and verify correct localized field compliance.",
    technicalTranslationAr: "بوابة لإنتاج نداءات (API Action Triggers) ومنظومة رسائل مجهزة وموثقة ومؤمنة بالكامل للتعاطي مع التحديات الميدانية للأنظمة.",
    technicalTranslationEn: "Strict service-oriented triggers designed to fire only upon verified ethical clearance from both the Shura and Mercy Layer filters.",
    hadithAr: "«إذا قامت الساعة وفي يد أحدكم فسيلة، فإن استطاع أن لا تقوم حتى يغرسها فليغرسها»",
    hadithEn: "'If the Resurrections begins while one of you has a seedling in his hand, if he can plant it before it stands, he should plant it.'"
  },
  {
    id: 8,
    slug: "safety-mercy",
    nameAr: "مكبح الأمان وتجاوز الرحمة (Layer 8)",
    nameEn: "Safety & Mercy Override (Layer 8)",
    philosophyAr: "الحارس الأخير للنظام: قفل أخلاقي يمنع أي قرار مجحف ويلغيه فوراً لصالح الرحمة العظمى، واضعاً مصلحة الإنسان فوق الميكانيكية البحتة.",
    philosophyEn: "The ultimate safety latch. Evaluates systemic distress and applies a global Mercy Override whenever analytical logic outputs a dry or burdensome action.",
    seerahPrecedentAr: "حديث المرأة التي دخلت النار بقطة حبستها، ورأفة النبي بأم سلمة يوم الحديبية، وإرسائه لمبدأ منع الضرر والضرار ومسح ديون المعسرين.",
    seerahPrecedentEn: "The historical rule of 'Al-Ghurm' (forgiving the overburdened debtor) and the absolute prohibition of collateral damage in all forms of civil engagements.",
    caliphatePrecedentAr: "العهد والوصية الإنسانية الخالدة من علي بن أبي طالب رضي الله عنه لواليه مالك الأشتر في مصر، آمراً إياه بالرأفة بالرعية: «وأشعر قلبك الرحمة للرعية والمحبة لهم واللطف بهم... فإنهم صنفان: إما أخ لك في الدين أو نظير لك في الخلق»، مكرساً صدارة الرحمة كمكبح أمني أخلاقي حاكم يُبطل العسف والقانون القاحل.",
    caliphatePrecedentEn: "Fourth Caliph Ali ibn Abi Talib's legendary humanistic manual written to governor Malik al-Ashtar: 'Infuse your heart with mercy, love, and kindness for your subjects... for they are of two types: either your brother in faith or your equal in creation.' Subordinating raw legalism to universal safety-mercy locks.",
    technicalTranslationAr: "مفتاح الأمان الهاردويري (Mercy Kill-Switch) يبطل القرارات التي تجتاز المعايير الشكلية لكنها تؤدي للشقاء الفعلي للبشر.",
    technicalTranslationEn: "The ultimate kill-switch lock over the execution dispatch. Overrides correct decisions with high compassionate utility modifiers.",
    hadithAr: "«لا ضرر ولا ضرار»",
    hadithEn: "'There should be neither harming (of oneself/others) nor reciprocating of harm.'"
  }
];
